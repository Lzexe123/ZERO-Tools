<h1 align="center">ZERO TOOL Multi-Tool 🐯</h1> 
<p align="center">
  <img src="https://img.shields.io/github/v/release/fluzyteck/RedTiger-Tools?label=Version&color=a80505">
  <img src="https://img.shields.io/github/stars/fluzyteck/RedTiger-tools?style=flat&label=Stars&color=a80505">
  <img src="https://img.shields.io/github/repo-size/fluzyteck/RedTiger-Tools?label=Size&color=a80505">
  <img src="https://img.shields.io/github/languages/top/fluzyteck/RedTiger-Tools?color=a80505">

</p>
<img src="Img/RedTiger.png" wdth="9999">
<p>
The "<a href="https://github.com/loxyteck/RedTiger-Tools/blob/main/Settings/Program/Builder-Stealer.py">Builder Stealer</a>" and "<a href="https://github.com/loxyteck/RedTiger-Tools/blob/main/Settings/Program/Discord-Get-Your-Token.py">Discord Get Your Token</a>" options are detected by the antivirus even though there is no backdoor.<br>
I'll let you check the code for each of the options, there is no backdoor.
</p>
<h1>📜・Description:</h1>
<p>
  
👨‍💻 -> Developed in <strong>Python</strong>.<br>
🌍 -> Tool in <strong>English</strong>.<br>
💻 -> Available on <strong>Windows</strong> and <strong>Linux</strong><br>
🔎 -> <strong>No viruses</strong> or <strong>token grabbers</strong>.<br>
📂 -> <strong>Open Source</strong> only for verification, ensuring no viruses or malicious programs.<br>
🔄 -> <strong>Frequently updated</strong>.<br>
💰 -> <strong>Free</strong> for everyone.<br>
</p>

<h1>⚙️・Functions:</h1>
<p align="center">
  
```
   [Page n°1]
   [01] -> Tool Info                      [11] -> Builder Stealer                [21] -> Discord Token To Id And Brute
   [02] -> Tool Website                   [12] -> Sql Vulnerability              [22] -> Discord Token Server Raid
   [03] -> Ip Info                        [13] -> Search In DataBase             [23] -> Discord Token Spammer
   [04] -> Ip Pinger                      [14] -> Illegal Website                [24] -> Discord Token Delete Friends
   [05] -> Ip Generator                   [15] -> Discord Get Your Token         [25] -> Discord Token Block Friends
   [06] -> Ip Website                     [16] -> Discord Token Info             [26] -> Discord Token Mass Dm
   [07] -> Dox Tracker                    [17] -> Discord Token Nuker            [27] -> Discord Token Delete Dm
   [08] -> Dox Create                     [18] -> Discord Token Joiner           [28] -> Discord Token Status Changer
   [09] -> Number Info                    [19] -> Discord Token Leaver           [29] -> Discord Token Language Changer
   [10] -> Email Info                     [20] -> Discord Token Login            [30] -> Next Page >>
  
   [Page n°2]
   [31] -> << Previous Page               [41] -> Discord Webhook Spammer      
   [32] -> Discord Token House Changer    [42] -> Discord Webhook Generator      
   [33] -> Discord Token Theme Changer    [43] -> Roblox Cookie Login           
   [34] -> Discord Token Generator        [44] -> Roblox Cookie Info            
   [35] -> Discord Bot Server Nuker       [45] -> Roblox User Info             
   [36] -> Discord Bot Invite To Id       [46] -> Roblox Id Info               
   [37] -> Discord Server Info         
   [38] -> Discord Nitro Generator      
   [39] -> Discord Webhook Info         
   [40] -> Discord Webhook Delete

┌───(username@ZERO)─[~]
└──$
```
</p>

<h1>🔒・Requirements:</h1>
<h3>Windows:</h3>
<p>
- You need to install <a href="https://www.python.org/downloads/">Python</a> with the <a href="Img/Python_Path.png">PATH</a> option.<br>
- Windows 10 & 11
</p>
<h3>Linux:</h3>
<p>
- Latest version of Python.<br>
- Linux recent version.
</p>

<h1>⏳・Installation:</h1>
<a href="https://github.com/fluzyteck/RedTiger/archive/main.zip">Dowloads Tools</a>
<h3>Windows:</h3>
<p>
  
```
- Launch "Setup.bat" or "Setup.py"
```
</p>
<h3>Linux:</h3>
<p>
  
```
1 - Open a terminal in the folder (right click > terminal)
2 - Write "python3 Setup.py"
```
</p>

<h1>⚠️・Terms of use:</h1>
<p>
RedTiger has been developed solely for educational purposes. This project has been created with good intentions and is intended for personal use only. By choosing to use RedTiger, you acknowledge and accept full responsibility for any consequences that may result from your actions.
</p>

<h2>🔗・Credits:</h2>
<p>
- <a href="https://discord.gg/AYjFQHaM2b">Discord Server</a><br>
- <a href="https://red-tiger.000webhostapp.com/accueil.html">Site Web</a><br>
- Creator: Loxyteck<br>
- Version: 4.0
</p>
